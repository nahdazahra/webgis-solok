--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.12
-- Dumped by pg_dump version 9.6.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.znt_desa DROP CONSTRAINT znt_desa_pkey;
ALTER TABLE public.znt_desa ALTER COLUMN gid DROP DEFAULT;
DROP TABLE public.znt_persil;
DROP SEQUENCE public.znt_desa_gid_seq;
DROP TABLE public.znt_desa;
DROP SEQUENCE public.gidp_seq;
DROP TABLE public.admin;
DROP EXTENSION postgis;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    nama character varying,
    passwd character varying
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: gidp_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gidp_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gidp_seq OWNER TO postgres;

--
-- Name: znt_desa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.znt_desa (
    kode_znt character varying,
    klas character varying,
    njop character varying,
    nir character varying,
    diskripsi character varying,
    geom public.geometry,
    did integer,
    obj_id integer,
    nama character varying,
    luas_tanah double precision,
    luas_bangunan numeric,
    gid integer NOT NULL
);


ALTER TABLE public.znt_desa OWNER TO postgres;

--
-- Name: znt_desa_gid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.znt_desa_gid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.znt_desa_gid_seq OWNER TO postgres;

--
-- Name: znt_desa_gid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.znt_desa_gid_seq OWNED BY public.znt_desa.gid;


--
-- Name: znt_persil; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.znt_persil (
    kode_znt character varying,
    klas character varying,
    njop character varying,
    nir character varying,
    diskripsi character varying,
    luas_tanah double precision,
    luas_bangunan numeric,
    geom public.geometry,
    did integer,
    obj_id integer,
    nama character varying,
    gid integer DEFAULT nextval('public.gidp_seq'::regclass)
);


ALTER TABLE public.znt_persil OWNER TO postgres;

--
-- Name: znt_desa gid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.znt_desa ALTER COLUMN gid SET DEFAULT nextval('public.znt_desa_gid_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3572.dat

--
-- Name: gidp_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gidp_seq', 1854, true);


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3442.dat

--
-- Data for Name: znt_desa; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3573.dat

--
-- Name: znt_desa_gid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.znt_desa_gid_seq', 2207, true);


--
-- Data for Name: znt_persil; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3574.dat

--
-- Name: znt_desa znt_desa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.znt_desa
    ADD CONSTRAINT znt_desa_pkey PRIMARY KEY (gid);


--
-- PostgreSQL database dump complete
--

